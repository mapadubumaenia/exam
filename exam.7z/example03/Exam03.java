package exam.example03;

import java.util.Arrays;
import java.util.Scanner;

//3. 첫줄에 숫자의 총개수 N이 입력됩니다. 
//2줄에 N개의 숫자가 랜덤하게 입력됩니다. 
//오름차순 정렬해서 화면에 표시하는 코드를 작성하세요 
//입력: 5
//5 2 3 4 1
//출력 1 2 3 4 5
public class Exam03 {
public static void main(String[] args) {
	
	Scanner sc=new Scanner(System.in);
	
    int a = sc.nextInt();
    
    int[] arr = new int[a];
    for (int i = 0; i < a; i++) {
        arr[i] = sc.nextInt();
    }
    
    Arrays.sort(arr);
	
    for (int num : arr) {
        System.out.print(num+" ");
        
    }
    
    sc.close();
}
}
