package exam.example02;


//[실습]
//* 지시한 사항 외에 코딩은 자유롭게 하세요
//2. a변수가 19 이상이면 성인 아니면 미성년자라고 화면에 표시하세요 
//단, a 변수에는 19가 있습니다.
//결과:  성인
public class Exam02 {
public static void main(String[] args) {
	int a=19;
	if (a>=19) {
		System.out.println("성인");
		}
	else {
		System.out.println("미성년자");
	}
}
	
	
	
}
