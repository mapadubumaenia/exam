package com.simplecoding.simpledms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SimpledmsApplicationTests {

	@Test
	void contextLoads() {
	}

}
