//package com.simplecoding.simpledms.exam;
//
////* 지시한 사항 외에 코딩은 자유롭게 하세요
////2. 생성자 DI와 컨트롤러를 만들려고 합니다.
////아래 코드 중 누락된 부분을 추가하세요
//
//import com.simplecoding.simpledms.dept.service.DeptService;
//import lombok.RequiredArgsConstructor;
//import org.springframework.stereotype.Controller;
//
//@RequiredArgsConstructor
//@Controller
//public class DeptController {
//    //        서비스 가져오기
//    private  final DeptService deptService;
//...
//}
//
// // 오류뜨는게 보기싫어서 주석처리 헀습니다. cntl+a 주석처리로 바꿔주시고 읽어주세용
//
//}
