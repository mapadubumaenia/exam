//package com.simplecoding.simpledms.exam;
//
//public class A {

//     1번문제
//    스프링의 DI, IOC, AOP에 대해서 설명해주세요
//    DI: 의존성 주입 : 객체가 필요한 의존 객체(서비스·DAO 등)를 직접 생성하지 않고 외부(스프링 컨테이너)에서 주입
//    IOC:      제어의 역전이라는 뜻으로   애플리케이션 코드가 직접 객체를 생성하고(new), 생명 주기를 관리하게 만드는 것
//    AOP:   Aspect-Oriented Programming, 관점 지향 프로그래밍: 로직(비즈니스 코드)과 공통 관심 사항(로깅, 트랜잭션, 보안 검사 등)을 분리해서 모듈화하는 기법
//
//
//
//}
