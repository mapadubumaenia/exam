--[실습]
--* 지시한 사항 외에 코딩은 자유롭게 하세요
--2. 사원명(ENAME)이 SCOTT 인 사람의 정보를 모두 화면에 표시하세요 
--사원테이블: EMPLOYEE


SELECT * FROM EMPLOYEE
WHERE ENAME = 'SCOTT';